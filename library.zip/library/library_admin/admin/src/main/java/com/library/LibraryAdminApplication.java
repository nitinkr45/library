package com.library;

import com.library.config.CustomBeanNameGenerator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

@SpringBootApplication
public class LibraryAdminApplication {

	public static void main(String[] args) {

		CustomBeanNameGenerator beanNameGenerator = new CustomBeanNameGenerator();
		beanNameGenerator.addBasePackages("com.library");
		new SpringApplicationBuilder(LibraryAdminApplication.class)
				.beanNameGenerator(beanNameGenerator)
				.run(args);
	}

}
