package com.library.controller;

import com.library.annotation.AdminController;
import com.library.dto.UserDTO;
import com.library.model.User;
import com.library.service.UserService;
import com.library.utils.AuthenticationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;

@AdminController
public class AuthenticationController {

    @Autowired
    private UserService userService;

    @ModelAttribute("user")
    public UserDTO userDTO(){
        return new UserDTO();
    }

    @GetMapping("registration")
    public String showRegistrationForm(Model model) {
        return "admin/page/registration";
    }

    @PostMapping("registration")
    public String registerUserAccount(@ModelAttribute("user") @Valid UserDTO userDto,
                                      BindingResult result) {

        User existing = userService.findByEmail(userDto.getEmail());
        if (existing != null) {
            result.rejectValue("email", null, "There is already an account registered with that email");
        }

        if (result.hasErrors()) {
            return "admin/page/registration";
        }

        userService.save(userDto);
        return "redirect:/admin/login?success";
    }

    @GetMapping("login")
    public String login(Model model){
        if(AuthenticationUtils.isAuthenticated()){
            return "redirect:/admin/home";
        }
        return "admin/page/login";
    }


}
