package com.library.model;

public enum RoleName {
    ROLE_LIBRARIAN,
    ROLE_ADMIN,
    ROLE_STUDENT
}
