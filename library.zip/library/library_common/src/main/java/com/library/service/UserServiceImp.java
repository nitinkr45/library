package com.library.service;

import com.library.dao.RoleDao;
import com.library.dao.UserDao;
import com.library.dto.UserDTO;
import com.library.exception.AppException;
import com.library.mapper.UserMapper;
import com.library.model.Role;
import com.library.model.RoleName;
import com.library.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Collections;
import java.util.stream.Collectors;

@Service
public class UserServiceImp implements UserService {

    @Autowired
    UserDao userDao;

    @Autowired
    RoleDao roleDao;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Override
    public User findByEmail(String email) {
        return userDao.findByEmail(email).orElse(null);
    }

    @Override
    public User save(UserDTO userDto) throws AppException {
        User user = new User();

        user = UserMapper.from(userDto);
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        Role userRole = roleDao.findByName(RoleName.ROLE_LIBRARIAN).orElseThrow(()-> new AppException("User Role not set."));
        user.setRoles(Collections.singleton(userRole));
        return userDao.save(user);
    }

    @Override
    public boolean existsByEmail(String email) {
        return userDao.existsByEmail(email);
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = userDao.findByEmail(email).orElseThrow(()->new UsernameNotFoundException("Invalid username or password"));

        return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(), mapRolesToAuthorities(user.getRoles()));
    }

    private Collection< ? extends GrantedAuthority> mapRolesToAuthorities(Collection<Role> roles){
        return roles.stream().
                map(role -> new SimpleGrantedAuthority(role.getName().name()))
                .collect(Collectors.toList());
    }

}
