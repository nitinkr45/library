package com.library.dto;

import com.library.annotation.FieldMatch;

import javax.validation.constraints.*;

@FieldMatch.List({
        @FieldMatch(first = "password", second = "confirmPassword", message = "Password does not match")
})
public class UserDTO {

    private Integer id;

    @NotEmpty(message = "Name may not be blank")
    @Size(min = 4, message = "Name must be greater than 3 character")
    private String name;

    @Email
    @NotEmpty(message = "Email may not be blank")
    private String email;

    @NotEmpty(message = "Password may not be blank")
    private String password;
    private String confirmPassword;

    private byte status;

    @AssertTrue
    private Boolean terms;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    public byte getStatus() {
        return status;
    }

    public void setStatus(byte status) {
        this.status = status;
    }

    public Boolean getTerms() {
        return terms;
    }

    public void setTerms(Boolean terms) {
        this.terms = terms;
    }

    @Override
    public String toString() {
        return "UserDTO{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", confirmPassword='" + confirmPassword + '\'' +
                ", status=" + status +
                ", terms=" + terms +
                '}';
    }
}
