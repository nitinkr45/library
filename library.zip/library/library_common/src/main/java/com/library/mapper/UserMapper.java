package com.library.mapper;

import com.library.dto.UserDTO;
import com.library.model.User;

public class UserMapper {
    public static User from(UserDTO userDto){
        User user = new User();
        if(userDto.getId() != null){
            user.setId(userDto.getId());
        }

        user.setName(userDto.getName());
        user.setEmail(userDto.getEmail());
        user.setPassword(userDto.getPassword());
        user.setStatus(userDto.getStatus());

        return user;
    }
}
