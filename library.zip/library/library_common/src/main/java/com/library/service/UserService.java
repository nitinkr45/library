package com.library.service;

import com.library.dto.UserDTO;
import com.library.model.User;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService {
    User findByEmail(String email);

    User save(UserDTO user);

    boolean existsByEmail(String email);
}
