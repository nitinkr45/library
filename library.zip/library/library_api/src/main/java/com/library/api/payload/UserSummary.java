package com.library.api.payload;

public class UserSummary {
    private Integer id;
    private String email;
    private String name;

    public UserSummary(Integer id, String username, String name) {
        this.id = id;
        this.email = username;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
