package com.library.api.payload;

public interface Response {
}
