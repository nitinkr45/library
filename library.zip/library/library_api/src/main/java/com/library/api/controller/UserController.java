package com.library.api.controller;


import com.library.api.payload.UserIdentityAvailability;
import com.library.api.payload.UserProfile;
import com.library.api.payload.UserSummary;
import com.library.api.security.CurrentUser;
import com.library.api.security.UserPrincipal;
import com.library.dao.UserDao;
import com.library.exception.ResourceNotFoundException;
import com.library.model.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    private UserDao userRepository;

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @GetMapping("/user/me")
    @PreAuthorize("hasRole('ROLE_LIBRARIAN')")
    public UserSummary getCurrentUser(@CurrentUser UserPrincipal currentUser) {
        //System.out.println("current user"+currentUser.toString());
        UserSummary userSummary = new UserSummary(currentUser.getId(), currentUser.getEmail(), currentUser.getName());
        return userSummary;
    }

    @GetMapping("/user/checkEmailAvailability")
    public UserIdentityAvailability checkEmailAvailability(@RequestParam(value = "email") String email) {
        Boolean isAvailable = !userRepository.existsByEmail(email);
        return new UserIdentityAvailability(isAvailable);
    }

    @GetMapping("/users/{email}")
    public UserProfile getUserProfile(@PathVariable(value = "email") String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));

        UserProfile userProfile = new UserProfile(user.getId(), user.getEmail(), user.getName(), user.getCreatedAt());

        return userProfile;
    }





}
