package com.library.api.payload;

import java.time.Instant;

public class UserProfile {
    private Integer id;
    private String email;
    private String name;
    private Instant joinedAt;

    public UserProfile(Integer id, String email, String name, Instant joinedAt) {
        this.id = id;
        this.email = email;
        this.name = name;
        this.joinedAt = joinedAt;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Instant getJoinedAt() {
        return joinedAt;
    }

    public void setJoinedAt(Instant joinedAt) {
        this.joinedAt = joinedAt;
    }
}
